    /*
     * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
     * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
     */
    package Classes;

import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
import java.util.ArrayList;
    /**
     *
     * @author Admin
     */
    public class Member {

        private int id;
        private String Name;
        private String Phone;
        private String Email;
        private String Gender;
        private byte[]  picture;

        public Member(int id, String Name, String Phone, String Email, String Gender, byte[] picture) {
            this.id = id;
            this.Name = Name;
            this.Phone = Phone;
            this.Email = Email;
            this.Gender = Gender;
            this.picture = picture;
        }

    public Member() {
    this.id = 0;
    this.Name = "";
    this.Phone = "";
    this.Email = "";
    this.Gender = "";
    this.picture = null;  // Hoặc new byte[0]; nếu bạn muốn khởi tạo một mảng byte rỗng
}




        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return Name;
        }

        public void setName(String Name) {
            this.Name = Name;
        }

        public String getPhone() {
            return Phone;
        }

        public void setPhone(String Phone) {
            this.Phone = Phone;
        }

        public String getEmail() {
            return Email;
        }

        public void setEmail(String Email) {
            this.Email = Email;
        }

        public String getGender() {
            return Gender;
        }

        public void setGender(String Gender) {
            this.Gender = Gender;
        }

        public byte[] getPicture() {
            return picture;
        }

        public void setPicture(byte[] picture) {
            this.picture = picture;
        }

        public void addmember(String Name, String Phone, String Email, String gender, byte[] img) {
    String insertQuery = "INSERT INTO `member`(`hovaten`, `sodienthoai`, `email`, `gender`, `picture`) VALUES (?,?,?,?,?)";
   
    try {
        PreparedStatement ps = DB.getConnection().prepareStatement(insertQuery);
                
        ps.setString(1, Name);
        ps.setString(2, Phone);
        ps.setString(3, Email);
        ps.setString(4, gender);
        ps.setBytes(5, img);
        
        if (ps.executeUpdate() != 0) {
            
            JOptionPane.showMessageDialog(null, "Member Added", "Add Member", JOptionPane.INFORMATION_MESSAGE);
        } 
        else {
            JOptionPane.showMessageDialog(null, "Member Not Added", "Add Member", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException ex) {
         Logger.getLogger(DB.class.getName()).log(Level.SEVERE, null, ex);
    }
}
public void editmember(Integer ID, String Name, String Phone, String Email, String gender, byte[] img) {
    String insertQuery = "UPDATE `member` SET `hovaten`=?,`sodienthoai`=?,`email`=?,`gender`=?,`picture`=? WHERE `id`=?";
   
    try {
        PreparedStatement ps = DB.getConnection().prepareStatement(insertQuery);
                
        ps.setString(1, Name);
        ps.setString(2, Phone);
        ps.setString(3, Email);
        ps.setString(4, gender);
        ps.setBytes(5, img);
        ps.setInt(6,ID);
        
        if (ps.executeUpdate() != 0) {
            
            JOptionPane.showMessageDialog(null, "Member Edited", "edit member", 1);
        } 
        else {
            JOptionPane.showMessageDialog(null, "Member Not Edited", "edit member", 2);
        }
    } catch (SQLException ex) {
         Logger.getLogger(Member.class.getName()).log(Level.SEVERE, null, ex);
    }
}
public void removeMember(int ID) {
    String query = "DELETE FROM `member` WHERE `id` = ?";
    
    try (PreparedStatement ps = DB.getConnection().prepareStatement(query)) {
        ps.setInt(1, ID);
        
        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(null, "Member Deleted Successfully", "Remove",1);
        } else {
                   JOptionPane.showMessageDialog(null, "No Member Found with Given ID", "Remove", 2);
              
        }
    } catch (SQLException ex) {
        Logger.getLogger(Member.class.getName()).log(Level.SEVERE, null, ex);
    }
}

public Member getMemberById(Integer id) throws SQLException {
    
    Func_class func = new Func_class();
    
    String query = "SELECT * FROM `member` WHERE `id`= "+id;
    
    ResultSet rs = func.getData(query);
    // Add your logic to process the ResultSet and return the Member object
            
    if(rs.next()) {
        return  new  Member(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getBytes(6));
    }
    else {
        return null;
    }
}

public ArrayList<Member> memberlistt(String query){

        ArrayList<Member> mlist = new ArrayList<>();
    Classes.Func_class func = new Func_class();

try {
    
    if(query.equals("")){
            
        query = "SELECT * FROM member";
        
    }
    
    ResultSet rs = func.getData(query);

    Member member;

    while(rs.next()) {
        member = new Member(rs.getInt("id"), rs.getString("hovaten"), rs.getString("sodienthoai"),rs.getString("email"),rs.getString("gender"),rs.getBytes("picture"));
        mlist.add(member);
    }
}catch (SQLException ex) {
    Logger.getLogger(Member.class.getName()).log(Level.SEVERE, null, ex);
}

        return mlist;
}

    }
    