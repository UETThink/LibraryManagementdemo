package Classes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
/**
 *
 * @author Acer
 */
public class Func_class {
    
    // Xóa dòng này:
    // Classes.Func_class func = new Classes.Func_class();
    
    public void displayImage(int width, int height, byte[] imagebyte, String imagePath, JLabel label) {
    // Lấy hình ảnh
    
    ImageIcon imgIco;
    if(imagebyte != null){
        
          imgIco = new ImageIcon(imagebyte);
    }
    
    else{
            try {
                imgIco = new ImageIcon(getClass().getResource(imagePath));
            }
            catch(Exception e){
                      imgIco = new ImageIcon(imagePath);
            }
    
    }
  
    Image image = imgIco.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
    
    // Đặt hình ảnh vào nhãn
    label.setIcon(new ImageIcon(image));
}
    
    public void customTableHeader(JTable table, Color backgroundColor, int fontSize) {
        table.getTableHeader().setBackground(backgroundColor);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(new Font("Verdana", Font.BOLD, fontSize));
        table.getTableHeader().setOpaque(false);
    }

    public ResultSet getData(String query) {
        ResultSet resultSet = null;
        try {
            System.out.println("SQL Query: " + query); // In câu truy vấn
            PreparedStatement preparedStatement = DB.getConnection().prepareStatement(query);
            resultSet = preparedStatement.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultSet;
    }
}
